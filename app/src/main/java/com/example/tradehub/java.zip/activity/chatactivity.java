package com.example.tradehub.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.LinkedList;
import com.example.tradehub.R;
public class chatactivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chatact);

        LinkedList<chatdata> myData = new LinkedList<>();
        for(int i = 0;i < 50;i++){
            if(i % 2 == 0){
                myData.add(new chatdata(R.drawable.buyer,"在吗",0));
            }
            else{
                myData.add(new chatdata(R.drawable.seller,"在",1));
            }
        }

        ListView listView = findViewById(R.id.listView_information);
        listView.setAdapter(new chatadapter(myData,this));
    }
}
